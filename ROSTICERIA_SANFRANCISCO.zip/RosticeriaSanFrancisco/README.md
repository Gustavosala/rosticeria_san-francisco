# Rosticería San Francisco

Proyecto Java Swing de demostración para importar en Eclipse.

## Requisitos
- Eclipse IDE con soporte Java.
- JDK 17 o posterior.
- No requiere MySQL ni bibliotecas externas para ejecutar esta versión.

## Importar en Eclipse
1. Descomprime `RosticeriaSanFrancisco.zip` en una carpeta.
2. En Eclipse selecciona **File > Import... > General > Existing Projects into Workspace**.
3. En **Select root directory**, elige la carpeta `RosticeriaSanFrancisco` descomprimida.
4. Selecciona el proyecto y pulsa **Finish**.
5. Abre `src/rosticeria/Inicio.java`, clic derecho y elige **Run As > Java Application**.

## Cuentas de demostración
- Cajero: usuario `cajero`, contraseña `1234`.
- Administrador: usuario `admin`, contraseña `admin123`.

En el login selecciona también el rol correspondiente.

## Funcionalidad
- Cajero: registrar productos y realizar ventas.
- Administrador: consultar inventario y revisar ventas del día.
- Se incluyen algunos productos de ejemplo.

## Importante
Esta versión mantiene productos y ventas **solo en memoria**: los datos se reinician al cerrar la aplicación. Es una base funcional para probar las interfaces y no está preparada todavía para operación comercial real ni para usuarios/contraseñas seguros. La conexión MySQL del proyecto original no se usa en esta versión independiente.
