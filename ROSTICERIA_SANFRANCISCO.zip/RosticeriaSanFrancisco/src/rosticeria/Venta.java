package rosticeria;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Venta {
    private final LocalDateTime fecha;
    private final String producto;
    private final int cantidad;
    private final double total;
    public Venta(String producto, int cantidad, double total) {
        this.fecha = LocalDateTime.now(); this.producto = producto; this.cantidad = cantidad; this.total = total;
    }
    public LocalDateTime getFecha() { return fecha; }
    public String getFechaTexto() { return fecha.format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")); }
    public String getProducto() { return producto; }
    public int getCantidad() { return cantidad; }
    public double getTotal() { return total; }
}
