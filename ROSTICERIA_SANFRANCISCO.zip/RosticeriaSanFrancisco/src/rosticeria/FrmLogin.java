package rosticeria;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.*;

public class FrmLogin extends JFrame {
    private final JTextField txtUsuario = new JTextField("cajero");
    private final JPasswordField txtClave = new JPasswordField("1234");
    private final JComboBox<String> cmbRol = new JComboBox<>(new String[]{"Cajero", "Administrador"});

    public FrmLogin() {
        setTitle("Rosticería San Francisco - Inicio de sesión");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(430, 330);
        setLocationRelativeTo(null);
        getContentPane().setBackground(Estilo.CREMA);
        JPanel principal = new JPanel(new BorderLayout(12, 18));
        principal.setBorder(BorderFactory.createEmptyBorder(22, 28, 22, 28));
        principal.setBackground(Estilo.CREMA);
        principal.add(Estilo.titulo("ROSTICERÍA SAN FRANCISCO"), BorderLayout.NORTH);
        JPanel campos = new JPanel(new GridLayout(3, 2, 10, 12));
        campos.setBackground(Estilo.CREMA);
        campos.add(new JLabel("Usuario:")); campos.add(txtUsuario);
        campos.add(new JLabel("Contraseña:")); campos.add(txtClave);
        campos.add(new JLabel("Tipo de usuario:")); campos.add(cmbRol);
        principal.add(campos, BorderLayout.CENTER);
        JButton entrar = Estilo.boton("Iniciar sesión");
        entrar.addActionListener(e -> iniciarSesion());
        getRootPane().setDefaultButton(entrar);
        principal.add(entrar, BorderLayout.SOUTH);
        add(principal);
    }

    private void iniciarSesion() {
        String usuario = txtUsuario.getText().trim();
        String clave = new String(txtClave.getPassword());
        String rol = (String) cmbRol.getSelectedItem();
        // Cuentas de demostración. Cambia las credenciales antes de usarlo en un negocio real.
        boolean valido = "Administrador".equals(rol)
                ? usuario.equals("admin") && clave.equals("admin123")
                : usuario.equals("cajero") && clave.equals("1234");
        if (!valido) {
            JOptionPane.showMessageDialog(this,
                    "Usuario o contraseña incorrectos para el rol seleccionado.", "Acceso denegado", JOptionPane.WARNING_MESSAGE);
            return;
        }
        dispose();
        if ("Administrador".equals(rol)) new FrmMenuAdministrador().setVisible(true);
        else new FrmMenuCajero().setVisible(true);
    }
}
