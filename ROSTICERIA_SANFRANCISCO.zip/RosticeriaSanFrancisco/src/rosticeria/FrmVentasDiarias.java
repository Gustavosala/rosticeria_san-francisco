package rosticeria;

import java.awt.BorderLayout;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class FrmVentasDiarias extends JFrame {
    private final DefaultTableModel modelo = new DefaultTableModel(new Object[]{"Fecha", "Producto", "Cantidad", "Total"}, 0) { public boolean isCellEditable(int r, int c) { return false; } };
    private final JLabel total = new JLabel();
    public FrmVentasDiarias() {
        setTitle("Ventas diarias"); setSize(700, 420); setLocationRelativeTo(null); setLayout(new BorderLayout(10, 10));
        add(Estilo.titulo("REPORTE DE VENTAS DEL DÍA"), BorderLayout.NORTH); add(new JScrollPane(new JTable(modelo)), BorderLayout.CENTER);
        JPanel sur = new JPanel(); JButton actualizar = Estilo.boton("Actualizar reporte"); actualizar.addActionListener(e -> cargar()); sur.add(total); sur.add(actualizar); add(sur, BorderLayout.SOUTH); cargar();
    }
    private void cargar() { modelo.setRowCount(0); for (Venta v : DatosSistema.VENTAS) if (v.getFecha().toLocalDate().equals(java.time.LocalDate.now())) modelo.addRow(new Object[]{v.getFechaTexto(), v.getProducto(), v.getCantidad(), String.format("$%.2f", v.getTotal())}); total.setText("Total vendido hoy: " + String.format("$%.2f", DatosSistema.totalVentasHoy())); }
}
