package rosticeria;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.*;

public class FrmMenuAdministrador extends JFrame {
    public FrmMenuAdministrador() {
        setTitle("Rosticería San Francisco - Menú de administrador"); setSize(480, 360);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); setLocationRelativeTo(null);
        JPanel p = new JPanel(new BorderLayout(15, 20)); p.setBorder(BorderFactory.createEmptyBorder(25, 35, 25, 35)); p.setBackground(Estilo.CREMA);
        p.add(Estilo.titulo("MENÚ DE ADMINISTRADOR"), BorderLayout.NORTH);
        JPanel botones = new JPanel(new GridLayout(3, 1, 10, 10)); botones.setBackground(Estilo.CREMA);
        JButton inventario = Estilo.boton("Inventario"); JButton ventas = Estilo.boton("Ventas diarias"); JButton salir = Estilo.boton("Cerrar sesión / Salir");
        inventario.addActionListener(e -> new FrmInventario().setVisible(true));
        ventas.addActionListener(e -> new FrmVentasDiarias().setVisible(true));
        salir.addActionListener(e -> { dispose(); new FrmLogin().setVisible(true); });
        botones.add(inventario); botones.add(ventas); botones.add(salir); p.add(botones, BorderLayout.CENTER); add(p);
    }
}
