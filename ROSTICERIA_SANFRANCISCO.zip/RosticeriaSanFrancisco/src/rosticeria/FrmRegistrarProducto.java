package rosticeria;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.*;

public class FrmRegistrarProducto extends JFrame {
    private final JTextField nombre = new JTextField();
    private final JTextField precio = new JTextField();
    private final JTextField stock = new JTextField();
    public FrmRegistrarProducto() {
        setTitle("Registrar producto"); setSize(430, 280); setLocationRelativeTo(null);
        JPanel p = new JPanel(new BorderLayout(12, 12)); p.setBorder(BorderFactory.createEmptyBorder(18, 22, 18, 22));
        p.add(Estilo.titulo("REGISTRAR PRODUCTO"), BorderLayout.NORTH);
        JPanel campos = new JPanel(new GridLayout(3, 2, 8, 10)); campos.add(new JLabel("Nombre:")); campos.add(nombre); campos.add(new JLabel("Precio ($):")); campos.add(precio); campos.add(new JLabel("Existencias:")); campos.add(stock); p.add(campos, BorderLayout.CENTER);
        JButton guardar = Estilo.boton("Guardar producto"); guardar.addActionListener(e -> guardar()); p.add(guardar, BorderLayout.SOUTH); add(p);
    }
    private void guardar() {
        String n = nombre.getText().trim();
        try {
            double pr = Double.parseDouble(precio.getText().trim()); int st = Integer.parseInt(stock.getText().trim());
            if (n.isEmpty() || pr < 0 || st < 0) throw new IllegalArgumentException();
            DatosSistema.PRODUCTOS.add(new Producto(DatosSistema.nuevoId(), n, pr, st));
            JOptionPane.showMessageDialog(this, "Producto registrado correctamente."); dispose();
        } catch (Exception ex) { JOptionPane.showMessageDialog(this, "Captura un nombre, un precio válido y existencias iguales o mayores que cero.", "Datos inválidos", JOptionPane.WARNING_MESSAGE); }
    }
}
