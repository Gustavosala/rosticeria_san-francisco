package rosticeria;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/** Datos compartidos mientras la aplicación está abierta. */
public final class DatosSistema {
    public static final List<Producto> PRODUCTOS = new ArrayList<>();
    public static final List<Venta> VENTAS = new ArrayList<>();
    private static int siguienteId = 1;
    static {
        PRODUCTOS.add(new Producto(siguienteId++, "Pollo asado", 180.00, 10));
        PRODUCTOS.add(new Producto(siguienteId++, "Medio pollo", 95.00, 12));
        PRODUCTOS.add(new Producto(siguienteId++, "Refresco", 25.00, 24));
    }
    private DatosSistema() { }
    public static int nuevoId() { return siguienteId++; }
    public static double totalVentasHoy() {
        LocalDate hoy = LocalDate.now();
        return VENTAS.stream().filter(v -> v.getFecha().toLocalDate().equals(hoy)).mapToDouble(Venta::getTotal).sum();
    }
}
