package rosticeria;

import java.awt.Color;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JLabel;

public final class Estilo {
    public static final Color ROJO = new Color(151, 35, 35);
    public static final Color CREMA = new Color(255, 248, 230);
    private Estilo() { }
    public static JLabel titulo(String texto) {
        JLabel l = new JLabel(texto, JLabel.CENTER);
        l.setFont(new Font("SansSerif", Font.BOLD, 23));
        l.setForeground(ROJO);
        return l;
    }
    public static JButton boton(String texto) {
        JButton b = new JButton(texto);
        b.setFont(new Font("SansSerif", Font.PLAIN, 14));
        return b;
    }
}
