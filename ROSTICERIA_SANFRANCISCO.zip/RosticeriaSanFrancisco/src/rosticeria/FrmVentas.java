package rosticeria;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.*;

public class FrmVentas extends JFrame {
    private final JComboBox<Producto> productos = new JComboBox<>();
    private final JTextField cantidad = new JTextField("1");
    public FrmVentas() {
        setTitle("Realizar venta"); setSize(500, 270); setLocationRelativeTo(null);
        JPanel p = new JPanel(new BorderLayout(12, 12)); p.setBorder(BorderFactory.createEmptyBorder(18, 22, 18, 22)); p.add(Estilo.titulo("REGISTRAR VENTA"), BorderLayout.NORTH);
        recargarProductos();
        JPanel campos = new JPanel(new GridLayout(2, 2, 8, 12)); campos.add(new JLabel("Producto:")); campos.add(productos); campos.add(new JLabel("Cantidad:")); campos.add(cantidad); p.add(campos, BorderLayout.CENTER);
        JButton vender = Estilo.boton("Cobrar venta"); vender.addActionListener(e -> vender()); p.add(vender, BorderLayout.SOUTH); add(p);
    }
    private void recargarProductos() {
        productos.removeAllItems();
        for (Producto prod : DatosSistema.PRODUCTOS) productos.addItem(prod);
        productos.setRenderer((list, value, index, selected, focus) -> new JLabel(value == null ? "Sin productos" : value.getNombre() + " - $" + String.format("%.2f", value.getPrecio()) + " (stock: " + value.getStock() + ")"));
    }
    private void vender() {
        Producto prod = (Producto) productos.getSelectedItem();
        try {
            int cant = Integer.parseInt(cantidad.getText().trim());
            if (prod == null || cant <= 0) throw new IllegalArgumentException();
            if (prod.getStock() < cant) { JOptionPane.showMessageDialog(this, "No hay existencias suficientes."); return; }
            double total = prod.getPrecio() * cant; prod.setStock(prod.getStock() - cant); DatosSistema.VENTAS.add(new Venta(prod.getNombre(), cant, total));
            JOptionPane.showMessageDialog(this, "Venta registrada.\nProducto: " + prod.getNombre() + "\nCantidad: " + cant + "\nTotal: $" + String.format("%.2f", total)); dispose();
        } catch (Exception ex) { JOptionPane.showMessageDialog(this, "Selecciona un producto y una cantidad entera mayor que cero.", "Datos inválidos", JOptionPane.WARNING_MESSAGE); }
    }
}
