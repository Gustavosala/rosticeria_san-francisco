package rosticeria;

import java.awt.BorderLayout;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class FrmInventario extends JFrame {
    private final DefaultTableModel modelo = new DefaultTableModel(new Object[]{"ID", "Producto", "Precio", "Existencias", "Valor en stock"}, 0) { public boolean isCellEditable(int r, int c) { return false; } };
    public FrmInventario() {
        setTitle("Inventario general"); setSize(700, 420); setLocationRelativeTo(null); setLayout(new BorderLayout(10, 10));
        add(Estilo.titulo("INVENTARIO GENERAL"), BorderLayout.NORTH); add(new JScrollPane(new JTable(modelo)), BorderLayout.CENTER);
        JButton actualizar = Estilo.boton("Actualizar"); actualizar.addActionListener(e -> cargar()); JPanel sur = new JPanel(); sur.add(actualizar); add(sur, BorderLayout.SOUTH); cargar();
    }
    private void cargar() { modelo.setRowCount(0); for (Producto p : DatosSistema.PRODUCTOS) modelo.addRow(new Object[]{p.getId(), p.getNombre(), String.format("$%.2f", p.getPrecio()), p.getStock(), String.format("$%.2f", p.getPrecio() * p.getStock())}); }
}
