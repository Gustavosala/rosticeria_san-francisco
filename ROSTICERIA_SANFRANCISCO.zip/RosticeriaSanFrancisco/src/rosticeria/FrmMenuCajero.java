package rosticeria;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.*;

public class FrmMenuCajero extends JFrame {
    public FrmMenuCajero() {
        setTitle("Rosticería San Francisco - Menú de cajero"); setSize(480, 360);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); setLocationRelativeTo(null);
        JPanel p = new JPanel(new BorderLayout(15, 20)); p.setBorder(BorderFactory.createEmptyBorder(25, 35, 25, 35)); p.setBackground(Estilo.CREMA);
        p.add(Estilo.titulo("MENÚ DE CAJERO"), BorderLayout.NORTH);
        JPanel botones = new JPanel(new GridLayout(3, 1, 10, 10)); botones.setBackground(Estilo.CREMA);
        JButton registrar = Estilo.boton("Registrar productos");
        JButton ventas = Estilo.boton("Realizar ventas");
        JButton salir = Estilo.boton("Cerrar sesión / Salir");
        registrar.addActionListener(e -> new FrmRegistrarProducto().setVisible(true));
        ventas.addActionListener(e -> new FrmVentas().setVisible(true));
        salir.addActionListener(e -> { dispose(); new FrmLogin().setVisible(true); });
        botones.add(registrar); botones.add(ventas); botones.add(salir); p.add(botones, BorderLayout.CENTER); add(p);
    }
}
