	
	package polleria;

	import javax.swing.*;
	import javax.swing.table.DefaultTableModel;
	import java.awt.*;
	import java.sql.*;

	public class ProductosPanel extends JPanel {

	    private JTextField txtId;
	    private JTextField txtNombre;
	    private JTextField txtPrecio;
	    private JTextField txtStock;

	    private JTable tabla;
	    private DefaultTableModel modelo;

	    public ProductosPanel() {

	        setLayout(new BorderLayout());


	        JPanel panelCampos = new JPanel(new GridLayout(2, 4, 10, 10));

	        panelCampos.add(new JLabel("ID:"));
	        panelCampos.add(new JLabel("Nombre:"));
	        panelCampos.add(new JLabel("Precio:"));
	        panelCampos.add(new JLabel("Stock:"));

	        txtId = new JTextField();
	        txtNombre = new JTextField();
	        txtPrecio = new JTextField();
	        txtStock = new JTextField();

	        txtId.setEditable(false);

	        panelCampos.add(txtId);
	        panelCampos.add(txtNombre);
	        panelCampos.add(txtPrecio);
	        panelCampos.add(txtStock);

	        add(panelCampos, BorderLayout.NORTH);


	        modelo = new DefaultTableModel();

	        modelo.addColumn("ID");
	        modelo.addColumn("Nombre");
	        modelo.addColumn("Precio");
	        modelo.addColumn("Stock");

	        tabla = new JTable(modelo);

	        JScrollPane scroll = new JScrollPane(tabla);

	        add(scroll, BorderLayout.CENTER);

	        
	        JPanel panelBotones = new JPanel();

	        JButton btnAgregar = new JButton("Agregar");
	        JButton btnModificar = new JButton("Modificar");
	        JButton btnEliminar = new JButton("Eliminar");
	        JButton btnLimpiar = new JButton("Limpiar");

	        panelBotones.add(btnAgregar);
	        panelBotones.add(btnModificar);
	        panelBotones.add(btnEliminar);
	        panelBotones.add(btnLimpiar);

	        add(panelBotones, BorderLayout.SOUTH);

	       

	        btnAgregar.addActionListener(e -> agregarProducto());

	        btnModificar.addActionListener(e -> modificarProducto());

	        btnEliminar.addActionListener(e -> eliminarProducto());

	        btnLimpiar.addActionListener(e -> limpiarCampos());

	        tabla.getSelectionModel().addListSelectionListener(e -> {

	            if (!e.getValueIsAdjusting()) {

	                int fila = tabla.getSelectedRow();

	                if (fila >= 0) {

	                    txtId.setText(
	                            modelo.getValueAt(fila, 0).toString()
	                    );

	                    txtNombre.setText(
	                            modelo.getValueAt(fila, 1).toString()
	                    );

	                    txtPrecio.setText(
	                            modelo.getValueAt(fila, 2).toString()
	                    );

	                    txtStock.setText(
	                            modelo.getValueAt(fila, 3).toString()
	                    );
	                }
	            }
	        });

	        cargarProductos();
	    }

	   

	    private void cargarProductos() {

	        modelo.setRowCount(0);

	        String sql = "SELECT * FROM productos";

	        try (Connection conexion = Conexion.conectar();
	             Statement stmt = conexion.createStatement();
	             ResultSet rs = stmt.executeQuery(sql)) {

	            while (rs.next()) {

	                modelo.addRow(new Object[]{

	                    rs.getInt("id_producto"),
	                    rs.getString("nombre"),
	                    rs.getDouble("precio"),
	                    rs.getInt("stock")

	                });
	            }

	        } catch (SQLException e) {

	            JOptionPane.showMessageDialog(
	                    this,
	                    "Error al cargar productos: "
	                    + e.getMessage()
	            );
	        }
	    }

	  
	    private void agregarProducto() {

	        String sql =
	                "INSERT INTO productos "
	                + "(nombre, precio, stock) "
	                + "VALUES (?, ?, ?)";

	        try (Connection conexion = Conexion.conectar();
	             PreparedStatement ps = conexion.prepareStatement(sql)) {

	            ps.setString(1, txtNombre.getText());
	            ps.setDouble(2, Double.parseDouble(txtPrecio.getText()));
	            ps.setInt(3, Integer.parseInt(txtStock.getText()));

	            ps.executeUpdate();

	            JOptionPane.showMessageDialog(
	                    this,
	                    "Producto agregado correctamente"
	            );

	            cargarProductos();
	            limpiarCampos();

	        } catch (SQLException e) {

	            JOptionPane.showMessageDialog(
	                    this,
	                    "Error: " + e.getMessage()
	            );
	        }
	    }

	  

	    private void modificarProducto() {

	        if (txtId.getText().isEmpty()) {

	            JOptionPane.showMessageDialog(
	                    this,
	                    "Selecciona un producto"
	            );

	            return;
	        }

	        String sql =
	                "UPDATE productos SET "
	                + "nombre = ?, "
	                + "precio = ?, "
	                + "stock = ? "
	                + "WHERE id_producto = ?";

	        try (Connection conexion = Conexion.conectar();
	             PreparedStatement ps = conexion.prepareStatement(sql)) {

	            ps.setString(1, txtNombre.getText());
	            ps.setDouble(2, Double.parseDouble(txtPrecio.getText()));
	            ps.setInt(3, Integer.parseInt(txtStock.getText()));
	            ps.setInt(4, Integer.parseInt(txtId.getText()));

	            ps.executeUpdate();

	            JOptionPane.showMessageDialog(
	                    this,
	                    "Producto modificado correctamente"
	            );

	            cargarProductos();
	            limpiarCampos();

	        } catch (SQLException e) {

	            JOptionPane.showMessageDialog(
	                    this,
	                    "Error: " + e.getMessage()
	            );
	        }
	    }

	   

	    private void eliminarProducto() {

	        if (txtId.getText().isEmpty()) {

	            JOptionPane.showMessageDialog(
	                    this,
	                    "Selecciona un producto"
	            );

	            return;
	        }

	        int respuesta = JOptionPane.showConfirmDialog(
	                this,
	                "¿Seguro que deseas eliminar este producto?",
	                "Confirmar",
	                JOptionPane.YES_NO_OPTION
	        );

	        if (respuesta != JOptionPane.YES_OPTION) {
	            return;
	        }

	        String sql =
	                "DELETE FROM productos "
	                + "WHERE id_producto = ?";

	        try (Connection conexion = Conexion.conectar();
	             PreparedStatement ps = conexion.prepareStatement(sql)) {

	            ps.setInt(
	                    1,
	                    Integer.parseInt(txtId.getText())
	            );

	            ps.executeUpdate();

	            JOptionPane.showMessageDialog(
	                    this,
	                    "Producto eliminado correctamente"
	            );

	            cargarProductos();
	            limpiarCampos();

	        } catch (SQLException e) {

	            JOptionPane.showMessageDialog(
	                    this,
	                    "No se puede eliminar el producto.\n"
	                    + e.getMessage()
	            );
	        }
	    }

	  
	    private void limpiarCampos() {

	        txtId.setText("");
	        txtNombre.setText("");
	        txtPrecio.setText("");
	        txtStock.setText("");

	        tabla.clearSelection();
	    }
	}

