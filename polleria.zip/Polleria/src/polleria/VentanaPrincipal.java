	
	package polleria;

	import javax.swing.JFrame;
	import javax.swing.JTabbedPane;

	public class VentanaPrincipal extends JFrame {

	    public VentanaPrincipal() {

	        setTitle("Sistema de Pollería");
	        setSize(900, 600);
	        setLocationRelativeTo(null);
	        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	        JTabbedPane pestañas = new JTabbedPane();

	        pestañas.addTab("Productos", new ProductosPanel());
	        pestañas.addTab("Clientes", new ClientesPanel());

	        add(pestañas);
	    }

	    public static void main(String[] args) {

	        VentanaPrincipal ventana = new VentanaPrincipal();
	        ventana.setVisible(true);
	    }
	}

