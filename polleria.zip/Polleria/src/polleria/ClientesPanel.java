	
	package polleria;

	import javax.swing.*;
	import javax.swing.table.DefaultTableModel;
	import java.awt.*;
	import java.sql.*;

	public class ClientesPanel extends JPanel {

	    private JTextField txtId;
	    private JTextField txtNombre;
	    private JTextField txtTelefono;
	    private JTextField txtCorreo;

	    private JTable tabla;
	    private DefaultTableModel modelo;

	    public ClientesPanel() {

	        setLayout(new BorderLayout());



	        JPanel panelCampos = new JPanel(new GridLayout(2, 4, 10, 10));

	        panelCampos.add(new JLabel("ID:"));
	        panelCampos.add(new JLabel("Nombre:"));
	        panelCampos.add(new JLabel("Teléfono:"));
	        panelCampos.add(new JLabel("Correo:"));

	        txtId = new JTextField();
	        txtNombre = new JTextField();
	        txtTelefono = new JTextField();
	        txtCorreo = new JTextField();

	    
	        txtId.setEditable(false);

	        panelCampos.add(txtId);
	        panelCampos.add(txtNombre);
	        panelCampos.add(txtTelefono);
	        panelCampos.add(txtCorreo);

	        add(panelCampos, BorderLayout.NORTH);



	        modelo = new DefaultTableModel();

	        modelo.addColumn("ID");
	        modelo.addColumn("Nombre");
	        modelo.addColumn("Teléfono");
	        modelo.addColumn("Correo");

	        tabla = new JTable(modelo);

	        JScrollPane scroll = new JScrollPane(tabla);

	        add(scroll, BorderLayout.CENTER);



	        JPanel panelBotones = new JPanel();

	        JButton btnAgregar = new JButton("Agregar");
	        JButton btnModificar = new JButton("Modificar");
	        JButton btnEliminar = new JButton("Eliminar");
	        JButton btnLimpiar = new JButton("Limpiar");

	        panelBotones.add(btnAgregar);
	        panelBotones.add(btnModificar);
	        panelBotones.add(btnEliminar);
	        panelBotones.add(btnLimpiar);

	        add(panelBotones, BorderLayout.SOUTH);

	     

	        btnAgregar.addActionListener(e -> agregarCliente());

	        btnModificar.addActionListener(e -> modificarCliente());

	        btnEliminar.addActionListener(e -> eliminarCliente());

	        btnLimpiar.addActionListener(e -> limpiarCampos());

	     
	        tabla.getSelectionModel().addListSelectionListener(e -> {

	            if (!e.getValueIsAdjusting()) {

	                int fila = tabla.getSelectedRow();

	                if (fila >= 0) {

	                    txtId.setText(
	                            modelo.getValueAt(fila, 0).toString()
	                    );

	                    txtNombre.setText(
	                            modelo.getValueAt(fila, 1).toString()
	                    );

	                    txtTelefono.setText(
	                            modelo.getValueAt(fila, 2).toString()
	                    );

	                    txtCorreo.setText(
	                            modelo.getValueAt(fila, 3).toString()
	                    );
	                }
	            }
	        });

	     
	        cargarClientes();
	    }

	

	    private void cargarClientes() {

	        modelo.setRowCount(0);

	        String sql = "SELECT * FROM clientes";

	        try (
	            Connection conexion = Conexion.conectar();
	            Statement stmt = conexion.createStatement();
	            ResultSet rs = stmt.executeQuery(sql)
	        ) {

	            while (rs.next()) {

	                modelo.addRow(new Object[]{

	                    rs.getInt("id_cliente"),
	                    rs.getString("nombre"),
	                    rs.getInt("telefono"),
	                    rs.getString("correo")

	                });
	            }

	        } catch (SQLException e) {

	            JOptionPane.showMessageDialog(
	                    this,
	                    "Error al cargar clientes:\n"
	                    + e.getMessage()
	            );
	        }
	    }

	

	    private void agregarCliente() {

	        String sql =
	                "INSERT INTO clientes "
	                + "(nombre, telefono, correo) "
	                + "VALUES (?, ?, ?)";

	        try (
	            Connection conexion = Conexion.conectar();
	            PreparedStatement ps =
	                    conexion.prepareStatement(sql)
	        ) {

	            ps.setString(1, txtNombre.getText());

	            ps.setInt(
	                    2,
	                    Integer.parseInt(txtTelefono.getText())
	            );

	            ps.setString(3, txtCorreo.getText());

	            ps.executeUpdate();

	            JOptionPane.showMessageDialog(
	                    this,
	                    "Cliente agregado correctamente"
	            );

	            cargarClientes();
	            limpiarCampos();

	        } catch (SQLException e) {

	            JOptionPane.showMessageDialog(
	                    this,
	                    "Error al agregar cliente:\n"
	                    + e.getMessage()
	            );

	        } catch (NumberFormatException e) {

	            JOptionPane.showMessageDialog(
	                    this,
	                    "El teléfono debe contener números."
	            );
	        }
	    }



	    private void modificarCliente() {

	        if (txtId.getText().isEmpty()) {

	            JOptionPane.showMessageDialog(
	                    this,
	                    "Selecciona un cliente primero."
	            );

	            return;
	        }

	        String sql =
	                "UPDATE clientes SET "
	                + "nombre = ?, "
	                + "telefono = ?, "
	                + "correo = ? "
	                + "WHERE id_cliente = ?";

	        try (
	            Connection conexion = Conexion.conectar();
	            PreparedStatement ps =
	                    conexion.prepareStatement(sql)
	        ) {

	            ps.setString(1, txtNombre.getText());

	            ps.setInt(
	                    2,
	                    Integer.parseInt(txtTelefono.getText())
	            );

	            ps.setString(3, txtCorreo.getText());

	            ps.setInt(
	                    4,
	                    Integer.parseInt(txtId.getText())
	            );

	            ps.executeUpdate();

	            JOptionPane.showMessageDialog(
	                    this,
	                    "Cliente modificado correctamente"
	            );

	            cargarClientes();
	            limpiarCampos();

	        } catch (SQLException e) {

	            JOptionPane.showMessageDialog(
	                    this,
	                    "Error al modificar cliente:\n"
	                    + e.getMessage()
	            );

	        } catch (NumberFormatException e) {

	            JOptionPane.showMessageDialog(
	                    this,
	                    "El teléfono debe contener números."
	            );
	        }
	    }



	    private void eliminarCliente() {

	        if (txtId.getText().isEmpty()) {

	            JOptionPane.showMessageDialog(
	                    this,
	                    "Selecciona un cliente primero."
	            );

	            return;
	        }

	        int respuesta = JOptionPane.showConfirmDialog(
	                this,
	                "¿Seguro que deseas eliminar este cliente?",
	                "Confirmar eliminación",
	                JOptionPane.YES_NO_OPTION
	        );

	        if (respuesta != JOptionPane.YES_OPTION) {
	            return;
	        }

	        String sql =
	                "DELETE FROM clientes "
	                + "WHERE id_cliente = ?";

	        try (
	            Connection conexion = Conexion.conectar();
	            PreparedStatement ps =
	                    conexion.prepareStatement(sql)
	        ) {

	            ps.setInt(
	                    1,
	                    Integer.parseInt(txtId.getText())
	            );

	            ps.executeUpdate();

	            JOptionPane.showMessageDialog(
	                    this,
	                    "Cliente eliminado correctamente"
	            );

	            cargarClientes();
	            limpiarCampos();

	        } catch (SQLException e) {

	            JOptionPane.showMessageDialog(
	                    this,
	                    "No se puede eliminar el cliente.\n"
	                    + "Puede tener pedidos asociados.\n\n"
	                    + e.getMessage()
	            );
	        }
	    }



	    private void limpiarCampos() {

	        txtId.setText("");
	        txtNombre.setText("");
	        txtTelefono.setText("");
	        txtCorreo.setText("");

	        tabla.clearSelection();
	    }
	}

