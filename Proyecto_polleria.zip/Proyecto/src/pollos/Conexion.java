package pollos;

import java.sql.Connection;
import java.sql.DriverManager;

public class Conexion {

    public static Connection conectar() {

        Connection conexion = null;

        try {

            conexion = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/polleria",
                "root",
                "1234"
            );

            System.out.println("Conexion exitosa");

        } catch (Exception e) {

            System.out.println("Error de conexion: " + e.getMessage());

        }

        return conexion;
    }
}