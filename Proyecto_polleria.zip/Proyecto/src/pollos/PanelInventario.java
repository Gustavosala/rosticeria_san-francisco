package pollos;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.JTable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.table.DefaultTableModel;
import javax.swing.JOptionPane;
import java.awt.Color;

public class PanelInventario extends JPanel {

	private static final long serialVersionUID = 1L;
	private JTable tablaInventario;

	private void cargarInventario() {

	    DefaultTableModel modelo = new DefaultTableModel();

	    modelo.addColumn("ID");
	    modelo.addColumn("Producto");
	    modelo.addColumn("Precio");
	    modelo.addColumn("Existencias");

	    String sql = "SELECT id_producto, nombre, precio, stock FROM productos";

	    try (Connection conexion = Conexion.conectar();
	         PreparedStatement ps = conexion.prepareStatement(sql);
	         ResultSet rs = ps.executeQuery()) {

	    	while (rs.next()) {

	    	    System.out.println("Producto encontrado: " + rs.getString("nombre"));

	    	    Object[] fila = {
	    	        rs.getInt("id_producto"),
	    	        rs.getString("nombre"),
	    	        rs.getDouble("precio"),
	    	        rs.getInt("stock")
	    	    };

	    	    modelo.addRow(fila);
	    	}

	        tablaInventario.setModel(modelo);

	    } catch (Exception e) {
	        JOptionPane.showMessageDialog(this,
	                "Error al cargar inventario: " + e.getMessage());
	    }
	}
	
	private void agregarProducto() {
	    String nombre = JOptionPane.showInputDialog(this, "Nombre del producto:");

	    if (nombre == null || nombre.trim().isEmpty()) {
	        return;
	    }

	    try {
	        String precioTexto = JOptionPane.showInputDialog(this, "Precio del producto:");
	        if (precioTexto == null) return;

	        String stockTexto = JOptionPane.showInputDialog(this, "Cantidad en existencia:");
	        if (stockTexto == null) return;

	        double precio = Double.parseDouble(precioTexto);
	        int stock = Integer.parseInt(stockTexto);

	        String sql = "INSERT INTO productos (nombre, precio, stock) VALUES (?, ?, ?)";

	        try (Connection conexion = Conexion.conectar();
	             PreparedStatement ps = conexion.prepareStatement(sql)) {

	            ps.setString(1, nombre);
	            ps.setDouble(2, precio);
	            ps.setInt(3, stock);

	            ps.executeUpdate();

	            JOptionPane.showMessageDialog(this, "Producto agregado correctamente.");
	            cargarInventario();
	        }

	    } catch (NumberFormatException e) {
	        JOptionPane.showMessageDialog(this, "Ingresa un precio y stock válidos.");
	    } catch (Exception e) {
	        JOptionPane.showMessageDialog(this, "Error al agregar: " + e.getMessage());
	    }
	}
	
	private void modificarStock() {
	    int fila = tablaInventario.getSelectedRow();

	    if (fila == -1) {
	        JOptionPane.showMessageDialog(this, "Selecciona un producto de la tabla.");
	        return;
	    }

	    int id = Integer.parseInt(tablaInventario.getValueAt(fila, 0).toString());

	    String stockTexto = JOptionPane.showInputDialog(
	        this, "Ingresa el nuevo stock:"
	    );

	    if (stockTexto == null) return;

	    try {
	        int stock = Integer.parseInt(stockTexto);

	        if (stock < 0) {
	            JOptionPane.showMessageDialog(this, "El stock no puede ser negativo.");
	            return;
	        }

	        String sql = "UPDATE productos SET stock = ? WHERE id_producto = ?";

	        try (Connection conexion = Conexion.conectar();
	             PreparedStatement ps = conexion.prepareStatement(sql)) {

	            ps.setInt(1, stock);
	            ps.setInt(2, id);

	            ps.executeUpdate();

	            JOptionPane.showMessageDialog(this, "Stock modificado correctamente.");
	            cargarInventario();
	        }

	    } catch (NumberFormatException e) {
	        JOptionPane.showMessageDialog(this, "Ingresa una cantidad válida.");
	    } catch (Exception e) {
	        JOptionPane.showMessageDialog(this, "Error al modificar: " + e.getMessage());
	    }
	}
	
	/**
	 * Create the panel.
	 */
	public PanelInventario() {
		setBackground(new Color(255, 128, 0));
		setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(100, 38, 484, 292);
		add(scrollPane);
		
		tablaInventario = new JTable();
		scrollPane.setViewportView(tablaInventario);
		
		JButton Actualizar = new JButton("Actualizar");
		Actualizar.setBounds(114, 382, 84, 66);
		add(Actualizar);
		
		JButton Modificar_stock = new JButton("Modificar stock");
		Modificar_stock.setBounds(457, 382, 84, 66);
		add(Modificar_stock);
		
		JButton Agregar = new JButton("Agregar");
		Agregar.setBounds(294, 382, 84, 66);
		add(Agregar);
		
		Actualizar.addActionListener(e -> cargarInventario());
		
		Agregar.addActionListener(e -> agregarProducto());
		
		Modificar_stock.addActionListener(e -> modificarStock());
		
		cargarInventario();

	}

}
