package pollos;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JButton;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.awt.Color;


public class PanelClientes extends JPanel {

	private static final long serialVersionUID = 1L;
	private JTable tablaClientes;

	//esta carga los datos desde mysql god
	private void cargarClientes() {

	    DefaultTableModel modelo = new DefaultTableModel();

	    modelo.addColumn("ID");
	    modelo.addColumn("Nombre");
	    modelo.addColumn("Telefono");
	    modelo.addColumn("Correo");

	    String sql = "SELECT * FROM clientes";

	    try (Connection conexion = Conexion.conectar()) {

	        if (conexion == null) {
	            JOptionPane.showMessageDialog(this, "No hay conexión con la base de datos");
	            return;
	        }

	        try (PreparedStatement ps = conexion.prepareStatement(sql);
	             ResultSet rs = ps.executeQuery()) {

	            while (rs.next()) {

	                Object[] fila = {
	                    rs.getInt("id_cliente"),
	                    rs.getString("nombre"),
	                    rs.getString("telefono"),
	                    rs.getString("correo")
	                };

	                modelo.addRow(fila);
	            }
	        }

	        tablaClientes.setModel(modelo);

	    } catch (Exception e) {
	        JOptionPane.showMessageDialog(this,
	            "Error al cargar clientes: " + e.getMessage());
	    }
	}
	
	//esta es paar el boton el cual agrega clientes
	private void agregarCliente() {

	    String nombre = JOptionPane.showInputDialog(this, "Nombre del cliente:");
	    if (nombre == null || nombre.trim().isEmpty()) return;

	    String telefono = JOptionPane.showInputDialog(this, "Teléfono:");
	    if (telefono == null || telefono.trim().isEmpty()) return;

	    String correo = JOptionPane.showInputDialog(this, "Correo:");
	    if (correo == null || correo.trim().isEmpty()) return;

	    String sql = "INSERT INTO clientes (nombre, telefono, correo) VALUES (?, ?, ?)";

	    try (Connection conexion = Conexion.conectar()) {

	        if (conexion == null) return;

	        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
	            ps.setString(1, nombre);
	            ps.setString(2, telefono);
	            ps.setString(3, correo);

	            ps.executeUpdate();
	        }

	        JOptionPane.showMessageDialog(this, "Cliente agregado correctamente");
	        cargarClientes();

	    } catch (Exception e) {
	        JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
	    }
	}
	
	//esta es pal boton de modificar clientes
	private void modificarCliente() {

	    int fila = tablaClientes.getSelectedRow();

	    if (fila == -1) {
	        JOptionPane.showMessageDialog(this, "Selecciona un cliente de la tabla");
	        return;
	    }

	    int id = Integer.parseInt(tablaClientes.getValueAt(fila, 0).toString());

	    String nombre = JOptionPane.showInputDialog(this, "Nuevo nombre:",
	            tablaClientes.getValueAt(fila, 1));

	    if (nombre == null || nombre.trim().isEmpty()) return;

	    String telefono = JOptionPane.showInputDialog(this, "Nuevo teléfono:",
	            tablaClientes.getValueAt(fila, 2));

	    if (telefono == null || telefono.trim().isEmpty()) return;

	    String correo = JOptionPane.showInputDialog(this, "Nuevo correo:",
	            tablaClientes.getValueAt(fila, 3));

	    if (correo == null || correo.trim().isEmpty()) return;

	    String sql = "UPDATE clientes SET nombre=?, telefono=?, correo=? WHERE id_cliente=?";

	    try (Connection conexion = Conexion.conectar()) {

	        if (conexion == null) return;

	        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
	            ps.setString(1, nombre);
	            ps.setString(2, telefono);
	            ps.setString(3, correo);
	            ps.setInt(4, id);

	            ps.executeUpdate();
	        }

	        JOptionPane.showMessageDialog(this, "Cliente modificado correctamente");
	        cargarClientes();

	    } catch (Exception e) {
	        JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
	    }
	}
	
	
	//esta  es pa eliminar clientes
	private void eliminarCliente() {

	    int fila = tablaClientes.getSelectedRow();

	    if (fila == -1) {
	        JOptionPane.showMessageDialog(this, "Selecciona un cliente de la tabla");
	        return;
	    }

	    int id = Integer.parseInt(tablaClientes.getValueAt(fila, 0).toString());

	    int confirmar = JOptionPane.showConfirmDialog(this,
	            "¿Seguro que deseas eliminar este cliente?",
	            "Confirmar eliminación",
	            JOptionPane.YES_NO_OPTION);

	    if (confirmar != JOptionPane.YES_OPTION) return;

	    String sql = "DELETE FROM clientes WHERE id_cliente=?";

	    try (Connection conexion = Conexion.conectar()) {

	        if (conexion == null) return;

	        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
	            ps.setInt(1, id);
	            ps.executeUpdate();
	        }

	        JOptionPane.showMessageDialog(this, "Cliente eliminado correctamente");
	        cargarClientes();

	    } catch (Exception e) {
	        JOptionPane.showMessageDialog(this,
	                "No se pudo eliminar. Puede que el cliente tenga pedidos registrados.\n"
	                + e.getMessage());
	    }
	}
	
	
	/**
	 * Create the panel.
	 */
	public PanelClientes() {
		setBackground(new Color(255, 128, 0));
		setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(70, 72, 599, 525);
		add(scrollPane);
		
		tablaClientes = new JTable();
		scrollPane.setViewportView(tablaClientes);
		
		JButton Agregar = new JButton("Agregar");
		Agregar.setBounds(804, 127, 125, 55);
		add(Agregar);
		
		JButton Modificar = new JButton("Modificar");
		Modificar.setBounds(804, 366, 125, 55);
		add(Modificar);
		
		JButton Eliminar = new JButton("Eliminar");
		Eliminar.setBounds(804, 242, 125, 55);
		add(Eliminar);
		
		JButton Actualizar = new JButton("Actualizar");
		Actualizar.setBounds(804, 492, 125, 55);
		add(Actualizar);
		
		Agregar.addActionListener(e -> agregarCliente());
		Modificar.addActionListener(e -> modificarCliente());
		Eliminar.addActionListener(e -> eliminarCliente());
		Actualizar.addActionListener(e -> cargarClientes());
		
		cargarClientes();

	}

}
