package pollos;

import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.Color;

public class PanelPedidos extends JPanel {

	private static final long serialVersionUID = 1L;
	private JTable tablaPedidos;

	
	
	private void cargarPedidos() {

	    DefaultTableModel modelo = new DefaultTableModel();

	    modelo.addColumn("ID");
	    modelo.addColumn("Cliente");
	    modelo.addColumn("Fecha");
	    modelo.addColumn("Total");
	    modelo.addColumn("Estado");

	    String sql = "SELECT p.id_pedido, c.nombre, p.fecha, p.total, p.estado "
	               + "FROM pedidos p "
	               + "INNER JOIN clientes c ON p.id_cliente = c.id_cliente";

	    try (Connection conexion = Conexion.conectar()) {

	        if (conexion == null) {
	            JOptionPane.showMessageDialog(this,
	                    "No hay conexión con la base de datos");
	            return;
	        }

	        try (PreparedStatement ps = conexion.prepareStatement(sql);
	             ResultSet rs = ps.executeQuery()) {
	        	while (rs.next()) {

	        	    System.out.println("Pedido encontrado: " + rs.getInt("id_pedido"));

	        	    Object[] fila = {
	        	        rs.getInt("id_pedido"),
	        	        rs.getString("nombre"),
	        	        rs.getTimestamp("fecha"),
	        	        rs.getDouble("total"),
	        	        rs.getString("estado")
	        	    };

	        	    modelo.addRow(fila);
	        	}
	        }

	        tablaPedidos.setModel(modelo);
	        
	        tablaPedidos.revalidate();
	        tablaPedidos.repaint();

	        System.out.println("Filas en la tabla: " + tablaPedidos.getRowCount());

	        
	    } catch (Exception e) {
	        JOptionPane.showMessageDialog(this,
	                "Error al cargar pedidos: " + e.getMessage());
	    }
	}
	
	
	//banda de pedidos mucho trabalo
	private void agregarPedido() {

	    String sqlClientes = "SELECT id_cliente, nombre FROM clientes";
	    String sqlProductos = "SELECT id_producto, nombre, precio, stock FROM productos";

	    try (Connection conexion = Conexion.conectar()) {

	        if (conexion == null) return;

	        // Seleccionar cliente cliente frecuenbte
	        java.util.ArrayList<Integer> idsClientes = new java.util.ArrayList<>();

	        javax.swing.JComboBox<String> comboClientes = new javax.swing.JComboBox<>();

	        try (PreparedStatement ps = conexion.prepareStatement(sqlClientes);
	             ResultSet rs = ps.executeQuery()) {

	            while (rs.next()) {
	                idsClientes.add(rs.getInt("id_cliente"));
	                comboClientes.addItem(rs.getString("nombre"));
	            }
	        }

	        if (idsClientes.isEmpty()) {
	            JOptionPane.showMessageDialog(this, "No hay clientes registrados");
	            return;
	        }

	        // Seleccionar producto a comprar 
	        java.util.ArrayList<Integer> idsProductos = new java.util.ArrayList<>();
	        java.util.ArrayList<Double> precios = new java.util.ArrayList<>();
	        java.util.ArrayList<Integer> stocks = new java.util.ArrayList<>();

	        javax.swing.JComboBox<String> comboProductos = new javax.swing.JComboBox<>();

	        try (PreparedStatement ps = conexion.prepareStatement(sqlProductos);
	             ResultSet rs = ps.executeQuery()) {

	            while (rs.next()) {
	                idsProductos.add(rs.getInt("id_producto"));
	                precios.add(rs.getDouble("precio"));
	                stocks.add(rs.getInt("stock"));
	                comboProductos.addItem(rs.getString("nombre"));
	            }
	        }

	        if (idsProductos.isEmpty()) {
	            JOptionPane.showMessageDialog(this, "No hay productos registrados");
	            return;
	        }

	        javax.swing.JTextField campoCantidad = new javax.swing.JTextField();

	        Object[] campos = {
	            "Selecciona el cliente:", comboClientes,
	            "Selecciona el producto:", comboProductos,
	            "Cantidad:", campoCantidad
	        };

	        int opcion = JOptionPane.showConfirmDialog(this, campos,
	                "Registrar pedido", JOptionPane.OK_CANCEL_OPTION);

	        if (opcion != JOptionPane.OK_OPTION) return;

	        int indiceCliente = comboClientes.getSelectedIndex();
	        int indiceProducto = comboProductos.getSelectedIndex();

	        int cantidad;

	        try {
	            cantidad = Integer.parseInt(campoCantidad.getText());

	            if (cantidad <= 0) {
	                JOptionPane.showMessageDialog(this, "La cantidad debe ser mayor que cero");
	                return;
	            }

	        } catch (NumberFormatException e) {
	            JOptionPane.showMessageDialog(this, "Ingresa una cantidad válida");
	            return;
	        }

	        int stock = stocks.get(indiceProducto);

	        if (cantidad > stock) {
	            JOptionPane.showMessageDialog(this, "No hay suficiente stock");
	            return;
	        }

	        int idCliente = idsClientes.get(indiceCliente);
	        int idProducto = idsProductos.get(indiceProducto);
	        double precio = precios.get(indiceProducto);
	        double total = precio * cantidad;

	        conexion.setAutoCommit(false);

	        try {
	            // Registrar pedido del cliente god
	            String sqlPedido = "INSERT INTO pedidos (id_cliente, fecha, total, estado) "
	                    + "VALUES (?, NOW(), ?, 'Pendiente')";

	            int idPedido;

	            try (PreparedStatement ps = conexion.prepareStatement(
	                    sqlPedido, java.sql.Statement.RETURN_GENERATED_KEYS)) {

	                ps.setInt(1, idCliente);
	                ps.setDouble(2, total);
	                ps.executeUpdate();

	                try (ResultSet rs = ps.getGeneratedKeys()) {
	                    if (!rs.next()) {
	                        throw new java.sql.SQLException("No se pudo obtener el ID del pedido");
	                    }
	                    idPedido = rs.getInt(1);
	                }
	            }

	            // Registrar detalle de la venta ggnext
	            String sqlDetalle = "INSERT INTO detalle_pedido "
	                    + "(id_pedido, id_producto, cantidad, precio) VALUES (?, ?, ?, ?)";

	            try (PreparedStatement ps = conexion.prepareStatement(sqlDetalle)) {
	                ps.setInt(1, idPedido);
	                ps.setInt(2, idProducto);
	                ps.setInt(3, cantidad);
	                ps.setDouble(4, precio);
	                ps.executeUpdate();
	            }

	            // Descontar dentro del inventario ggs
	            String sqlStock = "UPDATE productos SET stock = stock - ? "
	                    + "WHERE id_producto = ? AND stock >= ?";

	            try (PreparedStatement ps = conexion.prepareStatement(sqlStock)) {
	                ps.setInt(1, cantidad);
	                ps.setInt(2, idProducto);
	                ps.setInt(3, cantidad);

	                if (ps.executeUpdate() == 0) {
	                    throw new java.sql.SQLException("El stock cambió. Intenta nuevamente.");
	                }
	            }

	            conexion.commit();

	            JOptionPane.showMessageDialog(this,
	                    "Pedido registrado correctamente.\nTotal: $" + total);

	            cargarPedidos();

	        } catch (Exception e) {
	            conexion.rollback();
	            JOptionPane.showMessageDialog(this,
	                    "Error al registrar pedido: " + e.getMessage());
	        } finally {
	            conexion.setAutoCommit(true);
	        }

	    } catch (Exception e) {
	        JOptionPane.showMessageDialog(this,
	                "Error: " + e.getMessage());
	    }
	}
	
	
	//modificar el pedido
	private void modificarPedido() {

	    int fila = tablaPedidos.getSelectedRow();

	    if (fila == -1) {
	        JOptionPane.showMessageDialog(this, "Selecciona un pedido");
	        return;
	    }

	    int id = Integer.parseInt(
	            tablaPedidos.getValueAt(fila, 0).toString());

	    String estadoActual = tablaPedidos.getValueAt(fila, 4).toString();

	    String[] estados = {"Pendiente", "Preparando", "Entregado", "Cancelado"};

	    String nuevoEstado = (String) JOptionPane.showInputDialog(
	            this,
	            "Selecciona el nuevo estado:",
	            "Modificar pedido",
	            JOptionPane.QUESTION_MESSAGE,
	            null,
	            estados,
	            estadoActual
	    );

	    if (nuevoEstado == null) return;

	    String sql = "UPDATE pedidos SET estado=? WHERE id_pedido=?";

	    try (Connection conexion = Conexion.conectar()) {

	        if (conexion == null) return;

	        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
	            ps.setString(1, nuevoEstado);
	            ps.setInt(2, id);
	            ps.executeUpdate();
	        }

	        JOptionPane.showMessageDialog(this, "Estado actualizado correctamente");
	        cargarPedidos();

	    } catch (Exception e) {
	        JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
	    }
	}
	
	//eliminar el pedido noooooo
	private void eliminarPedido() {

	    int fila = tablaPedidos.getSelectedRow();

	    if (fila == -1) {
	        JOptionPane.showMessageDialog(this, "Selecciona un pedido");
	        return;
	    }

	    int id = Integer.parseInt(
	            tablaPedidos.getValueAt(fila, 0).toString());

	    int confirmar = JOptionPane.showConfirmDialog(
	            this,
	            "¿Deseas eliminar este pedido?",
	            "Confirmar eliminación",
	            JOptionPane.YES_NO_OPTION
	    );

	    if (confirmar != JOptionPane.YES_OPTION) return;

	    try (Connection conexion = Conexion.conectar()) {

	        if (conexion == null) return;

	        conexion.setAutoCommit(false);

	        try {
	            String sqlDetalle = "DELETE FROM detalle_pedido WHERE id_pedido=?";

	            try (PreparedStatement ps = conexion.prepareStatement(sqlDetalle)) {
	                ps.setInt(1, id);
	                ps.executeUpdate();
	            }

	            String sqlPedido = "DELETE FROM pedidos WHERE id_pedido=?";

	            try (PreparedStatement ps = conexion.prepareStatement(sqlPedido)) {
	                ps.setInt(1, id);
	                ps.executeUpdate();
	            }

	            conexion.commit();

	            JOptionPane.showMessageDialog(this, "Pedido eliminado correctamente");
	            cargarPedidos();

	        } catch (Exception e) {
	            conexion.rollback();
	            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());

	        } finally {
	            conexion.setAutoCommit(true);
	        }

	    } catch (Exception e) {
	        JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
	    }
	}
	
	/**
	 * Create the panel.
	 */
	public PanelPedidos() {
		setBackground(new Color(255, 128, 0));
		setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();

		scrollPane.setBounds(10, 10, 595, 314);
		add(scrollPane);

		tablaPedidos = new JTable();
		scrollPane.setViewportView(tablaPedidos);
		
		JButton Agregar = new JButton("Agregar");
		Agregar.setBounds(53, 357, 84, 53);
		add(Agregar);
		
		JButton Modificar = new JButton("Modificar");
		Modificar.setBounds(201, 357, 84, 53);
		add(Modificar);
		
		JButton Eliminar = new JButton("Eliminar");
		Eliminar.setBounds(348, 357, 84, 53);
		add(Eliminar);
		
		JButton Actualizar = new JButton("Actualizar");
		Actualizar.setBounds(506, 357, 84, 53);
		add(Actualizar);
		
		Agregar.addActionListener(e -> agregarPedido());

		Modificar.addActionListener(e -> modificarPedido());

		Eliminar.addActionListener(e -> eliminarPedido());

		Actualizar.addActionListener(e -> cargarPedidos());
		
		cargarPedidos();

	}

}
