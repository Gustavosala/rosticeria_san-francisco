package pollos;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Color;
import javax.swing.ImageIcon;
import java.awt.Font;


public class MenuPrincipal extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JPanel panelContenido;

	/**
	 * Launch the application.
	 */
	
	private void mostrarPanel(JPanel panel) {
	    panelContenido.removeAll();

	    panelContenido.setLayout(new BorderLayout());
	    panelContenido.add(panel, BorderLayout.CENTER);

	    panelContenido.revalidate();
	    panelContenido.repaint();
	}
	
	

	public MenuPrincipal(Usuario usuario) {
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1336, 714);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 128));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 128, 0));
		panel.setBounds(45, 105, 182, 452);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JButton Productos = new JButton("Productos");
		Productos.setFont(new Font("Tahoma", Font.BOLD, 12));
		Productos.setBounds(20, 23, 123, 58);
		panel.add(Productos);
		
		JButton Inventario = new JButton("Inventario");
		Inventario.setFont(new Font("Tahoma", Font.BOLD, 12));
		Inventario.setBounds(20, 90, 123, 58);
		panel.add(Inventario);
		
		JButton Usuario = new JButton("Usuario");
		Usuario.setFont(new Font("Tahoma", Font.BOLD, 12));
		Usuario.setBounds(20, 228, 123, 58);
		panel.add(Usuario);
		
		JButton Clientes = new JButton("Clientes");
		Clientes.setFont(new Font("Tahoma", Font.BOLD, 12));
		Clientes.setBounds(20, 158, 123, 58);
		panel.add(Clientes);
		
		Clientes.addActionListener(e -> {
		    PanelClientes clientes = new PanelClientes();
		    mostrarPanel(clientes);
		});
		
		JButton Pedidos = new JButton("Pedidos");
		Pedidos.setFont(new Font("Tahoma", Font.BOLD, 12));
		Pedidos.setBounds(20, 296, 123, 58);
		panel.add(Pedidos);
		
		JButton Reportes = new JButton("Reportes");
		Reportes.setFont(new Font("Tahoma", Font.BOLD, 12));
		Reportes.setBounds(20, 367, 123, 58);
		panel.add(Reportes);
		
		Reportes.addActionListener(e -> {
		    PanelReportes reportes = new PanelReportes();
		    mostrarPanel(reportes);
		});

		Pedidos.addActionListener(e -> {
		    PanelPedidos pedidos = new PanelPedidos();
		    mostrarPanel(pedidos);
		});

		Usuario.addActionListener(e -> {
		    PanelUsuario usuarios = new PanelUsuario();
		    mostrarPanel(usuarios);
		});

		Inventario.addActionListener(e -> {
		    PanelInventario inventario = new PanelInventario();
		    mostrarPanel(inventario);
		});

		Productos.addActionListener(e -> {
		    PanelProductos productos = new PanelProductos();
		    mostrarPanel(productos);
		});
		
		panelContenido = new JPanel();
		panelContenido.setBackground(new Color(250, 219, 97));
		panelContenido.setBounds(297, 105, 1015, 550);
		contentPane.add(panelContenido);
		panelContenido.setLayout(new BorderLayout());
		
		JLabel lblNewLabel = new JLabel("POLLERIA \"SAN FRANCISCO\"");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblNewLabel.setBounds(597, 38, 387, 56);
		contentPane.add(lblNewLabel);

	}
}
