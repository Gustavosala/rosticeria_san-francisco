package pollos;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.JTable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.awt.Color;


public class PanelUsuario extends JPanel {

	private static final long serialVersionUID = 1L;
	private JTable tablausuarios;

	private void cargarUsuarios() {
	    DefaultTableModel modelo = new DefaultTableModel();

	    modelo.addColumn("ID");
	    modelo.addColumn("Usuario");
	    modelo.addColumn("Contrasena");
	    modelo.addColumn("Rol");

	    String sql = "SELECT * FROM usuarios";

	    try (Connection conexion = Conexion.conectar();
	         PreparedStatement ps = conexion.prepareStatement(sql);
	         ResultSet rs = ps.executeQuery()) {

	        while (rs.next()) {
	            Object[] fila = {
	                rs.getInt("id_usuario"),
	                rs.getString("usuario"),
	                rs.getString("contrasena"),
	                rs.getString("rol")
	            };

	            modelo.addRow(fila);
	        }

	        tablausuarios.setModel(modelo);

	    } catch (Exception e) {
	        JOptionPane.showMessageDialog(this,
	            "Error al cargar usuarios: " + e.getMessage());
	    }
	}
	
	private void agregarUsuario() {

	    String usuario = JOptionPane.showInputDialog(this, "Nombre de usuario:");
	    if (usuario == null || usuario.trim().isEmpty()) return;

	    String contrasena = JOptionPane.showInputDialog(this, "Contraseña:");
	    if (contrasena == null || contrasena.trim().isEmpty()) return;

	    String rol = JOptionPane.showInputDialog(this, "Rol (Administrador/Empleado):");
	    if (rol == null || rol.trim().isEmpty()) return;

	    String sql = "INSERT INTO usuarios (usuario, contrasena, rol) VALUES (?, ?, ?)";

	    try (Connection conexion = Conexion.conectar();
	         PreparedStatement ps = conexion.prepareStatement(sql)) {

	        ps.setString(1, usuario);
	        ps.setString(2, contrasena);
	        ps.setString(3, rol);

	        ps.executeUpdate();

	        JOptionPane.showMessageDialog(this, "Usuario agregado correctamente.");
	        cargarUsuarios();

	    } catch (Exception e) {
	        JOptionPane.showMessageDialog(this,
	            "Error al agregar usuario: " + e.getMessage());
	    }
	}
	
	private void modificarUsuario() {

	    int fila = tablausuarios.getSelectedRow();

	    if (fila == -1) {
	        JOptionPane.showMessageDialog(this, "Selecciona un usuario.");
	        return;
	    }

	    int id = Integer.parseInt(
	        tablausuarios.getValueAt(fila, 0).toString()
	    );

	    String usuario = JOptionPane.showInputDialog(this, "Nuevo usuario:");
	    if (usuario == null || usuario.trim().isEmpty()) return;

	    String contrasena = JOptionPane.showInputDialog(this, "Nueva contraseña:");
	    if (contrasena == null || contrasena.trim().isEmpty()) return;

	    String rol = JOptionPane.showInputDialog(this, "Nuevo rol:");
	    if (rol == null || rol.trim().isEmpty()) return;

	    String sql = "UPDATE usuarios SET usuario = ?, contrasena = ?, rol = ? WHERE id_usuario = ?";

	    try (Connection conexion = Conexion.conectar();
	         PreparedStatement ps = conexion.prepareStatement(sql)) {

	        ps.setString(1, usuario);
	        ps.setString(2, contrasena);
	        ps.setString(3, rol);
	        ps.setInt(4, id);

	        ps.executeUpdate();

	        JOptionPane.showMessageDialog(this, "Usuario modificado correctamente.");
	        cargarUsuarios();

	    } catch (Exception e) {
	        JOptionPane.showMessageDialog(this,
	            "Error al modificar: " + e.getMessage());
	    }
	}
	
	private void eliminarUsuario() {

	    int fila = tablausuarios.getSelectedRow();

	    if (fila == -1) {
	        JOptionPane.showMessageDialog(this, "Selecciona un usuario.");
	        return;
	    }

	    int id = Integer.parseInt(
	        tablausuarios.getValueAt(fila, 0).toString()
	    );

	    int confirmar = JOptionPane.showConfirmDialog(
	        this,
	        "¿Estás seguro de eliminar este usuario?",
	        "Confirmar eliminación",
	        JOptionPane.YES_NO_OPTION
	    );

	    if (confirmar == JOptionPane.YES_OPTION) {

	        String sql = "DELETE FROM usuarios WHERE id_usuario = ?";

	        try (Connection conexion = Conexion.conectar();
	             PreparedStatement ps = conexion.prepareStatement(sql)) {

	            ps.setInt(1, id);
	            ps.executeUpdate();

	            JOptionPane.showMessageDialog(this, "Usuario eliminado correctamente.");
	            cargarUsuarios();

	        } catch (Exception e) {
	            JOptionPane.showMessageDialog(this,
	                "Error al eliminar: " + e.getMessage());
	        }
	    }
	}
	
	/**
	 * Create the panel.
	 */
	public PanelUsuario() {
		setBackground(new Color(255, 128, 0));
		setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(66, 25, 466, 212);
		add(scrollPane);
		
		tablausuarios = new JTable();
		scrollPane.setViewportView(tablausuarios);
		
		JButton Agregar = new JButton("Agregar");
		Agregar.setBounds(69, 281, 112, 66);
		add(Agregar);
		
		JButton Modificar = new JButton("Modificar");
		Modificar.setBounds(246, 281, 100, 66);
		add(Modificar);
		
		JButton Eliminar = new JButton("Eliminar");
		Eliminar.setBounds(429, 281, 93, 66);
		add(Eliminar);
		
		JButton Actualizar = new JButton("Actualizar");
		Actualizar.setBounds(596, 281, 100, 66);
		add(Actualizar);

		Actualizar.addActionListener(e -> cargarUsuarios());
		
		Agregar.addActionListener(e -> agregarUsuario());
		
		Modificar.addActionListener(e -> modificarUsuario());

		Eliminar.addActionListener(e -> eliminarUsuario());
		
		cargarUsuarios();
		
	}

}
