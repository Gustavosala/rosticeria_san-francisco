package pollos;

import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.table.DefaultTableModel;
import javax.swing.JOptionPane;
import java.sql.SQLException;
import java.awt.Color;



public class PanelProductos extends JPanel {

	private static final long serialVersionUID = 1L;
	private JTable tablaProductos;
	

	
	
	private void cargarProductos() {

	    DefaultTableModel modelo = new DefaultTableModel();

	    modelo.addColumn("ID");
	    modelo.addColumn("Nombre");
	    modelo.addColumn("Precio");
	    modelo.addColumn("Stock");

	    String sql = "SELECT * FROM productos";

	    try (Connection conexion = Conexion.conectar();
	         PreparedStatement ps = conexion.prepareStatement(sql);
	         ResultSet rs = ps.executeQuery()) {

	        while (rs.next()) {

	            Object[] fila = {
	                rs.getInt("id_producto"),
	                rs.getString("nombre"),
	                rs.getDouble("precio"),
	                rs.getInt("stock")
	            };

	            modelo.addRow(fila);
	        }

	        tablaProductos.setModel(modelo);

	    } catch (Exception e) {
	        System.out.println("Error al cargar productos: " + e.getMessage());
	    }
	}
	
	//agregar productos xdxd
	private void agregarProducto() {

	    String nombre = JOptionPane.showInputDialog(this, "Nombre del producto:");

	    if (nombre == null || nombre.trim().isEmpty()) {
	        return;
	    }

	    try {
	        String precioTexto = JOptionPane.showInputDialog(this, "Precio:");
	        if (precioTexto == null) return;

	        String stockTexto = JOptionPane.showInputDialog(this, "Stock:");
	        if (stockTexto == null) return;

	        double precio = Double.parseDouble(precioTexto);
	        int stock = Integer.parseInt(stockTexto);

	        if (precio <= 0 || stock < 0) {
	            JOptionPane.showMessageDialog(this, "Precio o stock no válido.");
	            return;
	        }

	        String sql = "INSERT INTO productos (nombre, precio, stock) VALUES (?, ?, ?)";

	        try (Connection conexion = Conexion.conectar()) {
	            if (conexion == null) {
	                JOptionPane.showMessageDialog(this, "No hay conexión con MySQL.");
	                return;
	            }

	            try (PreparedStatement ps = conexion.prepareStatement(sql)) {
	                ps.setString(1, nombre);
	                ps.setDouble(2, precio);
	                ps.setInt(3, stock);

	                ps.executeUpdate();
	            }
	        }

	        JOptionPane.showMessageDialog(this, "Producto agregado correctamente.");
	        cargarProductos();

	    } catch (NumberFormatException e) {
	        JOptionPane.showMessageDialog(this, "Ingresa un precio y stock válidos.");
	    } catch (Exception e) {
	        JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
	    }
	}
	
	
	//modificar al producto
	
	private void modificarProducto() {

	    int fila = tablaProductos.getSelectedRow();

	    if (fila == -1) {
	        JOptionPane.showMessageDialog(this, "Selecciona un producto de la tabla.");
	        return;
	    }

	    int id = Integer.parseInt(tablaProductos.getValueAt(fila, 0).toString());

	    String nombreActual = tablaProductos.getValueAt(fila, 1).toString();
	    String precioActual = tablaProductos.getValueAt(fila, 2).toString();
	    String stockActual = tablaProductos.getValueAt(fila, 3).toString();

	    String nombre = JOptionPane.showInputDialog(this, "Nuevo nombre:", nombreActual);
	    if (nombre == null || nombre.trim().isEmpty()) return;

	    try {
	        String precioTexto = JOptionPane.showInputDialog(this, "Nuevo precio:", precioActual);
	        if (precioTexto == null) return;

	        String stockTexto = JOptionPane.showInputDialog(this, "Nuevo stock:", stockActual);
	        if (stockTexto == null) return;

	        double precio = Double.parseDouble(precioTexto);
	        int stock = Integer.parseInt(stockTexto);

	        if (precio <= 0 || stock < 0) {
	            JOptionPane.showMessageDialog(this, "Precio o stock no válido.");
	            return;
	        }

	        String sql = "UPDATE productos SET nombre=?, precio=?, stock=? WHERE id_producto=?";

	        try (Connection conexion = Conexion.conectar()) {
	            if (conexion == null) {
	                JOptionPane.showMessageDialog(this, "No hay conexión con MySQL.");
	                return;
	            }

	            try (PreparedStatement ps = conexion.prepareStatement(sql)) {
	                ps.setString(1, nombre);
	                ps.setDouble(2, precio);
	                ps.setInt(3, stock);
	                ps.setInt(4, id);

	                ps.executeUpdate();
	            }
	        }

	        JOptionPane.showMessageDialog(this, "Producto modificado correctamente.");
	        cargarProductos();

	    } catch (NumberFormatException e) {
	        JOptionPane.showMessageDialog(this, "Ingresa datos numéricos válidos.");
	    } catch (Exception e) {
	        JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
	    }
	}
	
	
	//eliminar el producto por bot
	
	private void eliminarProducto() {

	    int fila = tablaProductos.getSelectedRow();

	    if (fila == -1) {
	        JOptionPane.showMessageDialog(this, "Selecciona un producto.");
	        return;
	    }

	    int id = Integer.parseInt(tablaProductos.getValueAt(fila, 0).toString());

	    int confirmar = JOptionPane.showConfirmDialog(
	        this,
	        "¿Estás seguro de eliminar este producto?",
	        "Confirmar eliminación",
	        JOptionPane.YES_NO_OPTION
	    );

	    if (confirmar != JOptionPane.YES_OPTION) {
	        return;
	    }

	    String sql = "DELETE FROM productos WHERE id_producto=?";

	    try (Connection conexion = Conexion.conectar()) {
	        if (conexion == null) {
	            JOptionPane.showMessageDialog(this, "No hay conexión con MySQL.");
	            return;
	        }

	        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
	            ps.setInt(1, id);
	            ps.executeUpdate();
	        }

	        JOptionPane.showMessageDialog(this, "Producto eliminado.");
	        cargarProductos();

	    } catch (SQLException e) {
	        JOptionPane.showMessageDialog(this,
	            "No se pudo eliminar. Es posible que el producto esté relacionado con un pedido.");
	    } catch (Exception e) {
	        JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
	    }
	}
	
	
	
	
	/**
	 * Create the panel.
	 */
	public PanelProductos() {
		setBackground(new Color(255, 128, 64));
	    setLayout(null);

	    JPanel panel = new JPanel();
	    panel.setBackground(new Color(255, 255, 128));
	    panel.setBounds(31, 38, 864, 515);
	    add(panel);
	    panel.setLayout(null);

	   
	    JScrollPane scrollPane_1 = new JScrollPane();
	    scrollPane_1.setBounds(82, 30, 749, 263);
	    panel.add(scrollPane_1);

	    tablaProductos = new JTable();
	    scrollPane_1.setViewportView(tablaProductos);

	   
	    JButton Agregar = new JButton("Agregar");
	    Agregar.setBounds(101, 303, 100, 76);
	    panel.add(Agregar);

	    JButton Eliminar = new JButton("Eliminar");
	    Eliminar.setBounds(698, 303, 100, 76);
	    panel.add(Eliminar);

	    JButton Modificar = new JButton("Modificar");
	    Modificar.setBounds(101, 411, 100, 70);
	    panel.add(Modificar);

	    JButton Actualizar = new JButton("Actualizar");
	    Actualizar.setBounds(698, 411, 100, 70);
	    panel.add(Actualizar);

	    Agregar.addActionListener(e -> agregarProducto());
	    

	    Modificar.addActionListener(e -> modificarProducto());

	    Eliminar.addActionListener(e -> eliminarProducto());

	    Actualizar.addActionListener(e -> cargarProductos());
	    
	    
	    
	    
	    cargarProductos();

	}
}
