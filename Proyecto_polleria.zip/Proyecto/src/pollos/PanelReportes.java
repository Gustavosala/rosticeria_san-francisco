package pollos;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import java.awt.Color;
import java.awt.Font;


public class PanelReportes extends JPanel {
	
	private JLabel Productos;
	private JLabel Clientes;
	private JLabel Pedidos;
	private JLabel Ventas;
	private JLabel Stock;

	private static final long serialVersionUID = 1L;

	private void cargarReportes() {

	    String sql = "SELECT "
	            + "(SELECT COUNT(*) FROM productos) AS productos, "
	            + "(SELECT COUNT(*) FROM clientes) AS clientes, "
	            + "(SELECT COUNT(*) FROM pedidos) AS pedidos, "
	            + "(SELECT COALESCE(SUM(total), 0) FROM pedidos) AS ventas, "
	            + "(SELECT COALESCE(SUM(stock), 0) FROM productos) AS stock";

	    try (Connection conexion = Conexion.conectar();
	         PreparedStatement ps = conexion.prepareStatement(sql);
	         ResultSet rs = ps.executeQuery()) {

	        if (rs.next()) {
	            Productos.setText("Total de productos: " + rs.getInt("productos"));
	            Clientes.setText("Total de clientes: " + rs.getInt("clientes"));
	            Pedidos.setText("Total de pedidos: " + rs.getInt("pedidos"));
	            Ventas.setText("Total de ventas: $" + rs.getDouble("ventas"));
	            Stock.setText("Stock disponible: " + rs.getInt("stock"));
	        }

	    } catch (Exception e) {
	        JOptionPane.showMessageDialog(this,
	                "Error al cargar reportes: " + e.getMessage());
	    }
	}
	
	/**
	 * Create the panel.
	 */
	public PanelReportes() {
		setBackground(new Color(255, 128, 0));
		setLayout(null);
		
		Productos = new JLabel("");
		Productos.setFont(new Font("Tahoma", Font.BOLD, 20));
		Productos.setForeground(new Color(0, 0, 0));
		Productos.setBackground(new Color(192, 192, 192));
		Productos.setBounds(92, 69, 326, 55);
		add(Productos);
		
		Clientes = new JLabel("");
		Clientes.setFont(new Font("Tahoma", Font.BOLD, 20));
		Clientes.setBounds(446, 69, 381, 55);
		add(Clientes);
		
		Pedidos = new JLabel("");
		Pedidos.setFont(new Font("Tahoma", Font.BOLD, 20));
		Pedidos.setBounds(92, 203, 326, 47);
		add(Pedidos);
		
		Ventas = new JLabel("");
		Ventas.setFont(new Font("Tahoma", Font.BOLD, 20));
		Ventas.setBounds(456, 203, 371, 47);
		add(Ventas);
		
		Stock = new JLabel("");
		Stock.setFont(new Font("Tahoma", Font.BOLD, 20));
		Stock.setBounds(92, 313, 343, 47);
		add(Stock);
		
		JButton Actualizar = new JButton("Actualizar");
		Actualizar.setFont(new Font("Tahoma", Font.BOLD, 25));
		Actualizar.setBounds(525, 309, 180, 51);
		add(Actualizar);

		Actualizar.addActionListener(e -> cargarReportes());

		cargarReportes();
		
	}

}
