package pollos;



import java.awt.EventQueue;
import javax.swing.JPasswordField;
import javax.swing.JOptionPane;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import java.awt.Font;

public class Interfaz extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtUsuario;
	private JPasswordField txtContrasena;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Interfaz frame = new Interfaz();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Interfaz() {
		setBackground(new Color(255, 128, 64));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 503, 554);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 0, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnIniciar = new JButton("Iniciar");
		
		btnIniciar.addActionListener(e -> {

		    String usuario = txtUsuario.getText();

		    String contrasena = new String(txtContrasena.getPassword());

		    Login login = new Login();

		    Usuario usuarioAutenticado =
		        login.validarUsuario(usuario, contrasena);

		    if (usuarioAutenticado != null) {

		        JOptionPane.showMessageDialog(this,
		            "Bienvenido " + usuarioAutenticado.getUsuario());

		        MenuPrincipal menu =
		            new MenuPrincipal(usuarioAutenticado);

		        menu.setVisible(true);

		        this.dispose();

		    } else {

		        JOptionPane.showMessageDialog(this,
		            "Usuario o contraseña incorrectos");

		    }

		});
		
		btnIniciar.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnIniciar.setBounds(248, 583, 84, 39);
		contentPane.add(btnIniciar);
		
		JLabel lblNewLabel = new JLabel("USUARIO");
		lblNewLabel.setLabelFor(this);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel.setForeground(Color.RED);
		lblNewLabel.setBounds(225, 377, 126, 36);
		contentPane.add(lblNewLabel);
		
		txtUsuario = new JTextField();
		txtUsuario.setBounds(179, 304, 207, 39);
		contentPane.add(txtUsuario);
		txtUsuario.setColumns(10);
		
		txtContrasena = new JPasswordField();
		txtContrasena.setBounds(179, 460, 207, 36);
		contentPane.add(txtContrasena);
		
		JLabel lblNewLabel_1 = new JLabel("Contraseña");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_1.setForeground(new Color(255, 0, 128));
		lblNewLabel_1.setBounds(213, 518, 160, 25);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_3 = new JLabel("Rosticeria\r\n\"San Francisco\"");
		lblNewLabel_3.setFont(new Font("Arial", Font.BOLD, 40));
		lblNewLabel_3.setForeground(new Color(255, 255, 0));
		lblNewLabel_3.setBounds(39, 57, 620, 225);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setIcon(new ImageIcon("C:\\Users\\gusta\\Downloads\\WhatsApp Image 2026-11-04 at 12.39.30 PM.jpeg"));
		lblNewLabel_2.setBounds(507, 89, 798, 680);
		contentPane.add(lblNewLabel_2);

	}
}
