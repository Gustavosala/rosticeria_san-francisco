package pollos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Login {

    public Usuario validarUsuario(String usuario, String contrasena) {

        String sql = "SELECT * FROM usuarios WHERE usuario = ? AND contrasena = ?";

        try (Connection conexion = Conexion.conectar()) {

            if (conexion == null) {
                return null;
            }

            try (PreparedStatement ps = conexion.prepareStatement(sql)) {

                ps.setString(1, usuario);
                ps.setString(2, contrasena);

                try (ResultSet rs = ps.executeQuery()) {

                    if (rs.next()) {

                        String nombre = rs.getString("usuario");
                        String password = rs.getString("contrasena");
                        String rol = rs.getString("rol");

                        return new Usuario(nombre, password, rol);
                    }
                }
            }

        } catch (Exception e) {

            System.out.println("Error: " + e.getMessage());
        }

        return null;
    }
}